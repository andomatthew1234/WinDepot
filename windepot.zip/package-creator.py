import os
import zipfile
import tkinter as tk
from tkinter import messagebox
import subprocess

# =========================
# CONFIG
# =========================
REPO_DIR = os.getcwd()
ZIP_NAME_PREFIX = "windepot_"
FINAL_ZIP_NAME = "windepot.zip"

# =========================
# ZIP CREATION
# =========================
def create_zip(version):
    zip_name = f"{ZIP_NAME_PREFIX}{version}.zip"
    zip_path = os.path.join(REPO_DIR, zip_name)

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(REPO_DIR):

            # exclude .git
            if ".git" in dirs:
                dirs.remove(".git")

            # exclude zip files
            for file in files:
                if file.endswith(".zip"):
                    continue

                file_path = os.path.join(root, file)

                # avoid including output zip itself
                if file_path == zip_path:
                    continue

                arcname = os.path.relpath(file_path, REPO_DIR)
                zipf.write(file_path, arcname)

    # also copy to fixed name for release pipeline
    final_zip_path = os.path.join(REPO_DIR, FINAL_ZIP_NAME)

    with open(zip_path, "rb") as src, open(final_zip_path, "wb") as dst:
        dst.write(src.read())

    return zip_path


# =========================
# GIT + RELEASE PIPELINE
# =========================
def publish_release(version):
    try:
        # commit zip
        subprocess.run(["git", "add", FINAL_ZIP_NAME], check=True)
        subprocess.run(["git", "commit", "-m", f"Release {version}"], check=True)

        # create tag
        subprocess.run(["git", "tag", version], check=True)

        # push commit + tag
        subprocess.run(["git", "push", "origin", "main"], check=True)
        subprocess.run(["git", "push", "origin", version], check=True)

        messagebox.showinfo(
            "Success",
            f"Release {version} published via Git tag!"
        )

    except subprocess.CalledProcessError as e:
        messagebox.showerror("Git Error", str(e))


# =========================
# MAIN PIPELINE
# =========================
def build_release(version):
    zip_path = create_zip(version)
    publish_release(version)


# =========================
# UI
# =========================
def on_submit():
    version = entry.get().strip()

    if not version:
        messagebox.showerror("Error", "Enter a version number")
        return

    try:
        build_release(version)
    except Exception as e:
        messagebox.showerror("Error", str(e))


root = tk.Tk()
root.title("WinDepot Release Builder")
root.geometry("360x160")
root.resizable(False, False)

label = tk.Label(root, text="Enter release version (e.g. 1.2.1)")
label.pack(pady=10)

entry = tk.Entry(root, width=25)
entry.pack()

btn = tk.Button(root, text="Build & Publish Release", command=on_submit)
btn.pack(pady=15)

root.mainloop()